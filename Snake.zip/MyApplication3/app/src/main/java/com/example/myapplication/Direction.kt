package com.example.myapplication

enum class Direction {
    stop, left, right, up, down
}