package com.example.myapplication

class Fruit(val column: Int, val row: Int, val resourceId: Int)